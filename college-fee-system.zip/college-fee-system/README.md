# College Fee System (pure Node.js)

No npm packages needed. Requires Node.js 16+.

    node server.js     # or: npm start

Open http://localhost:3000 - login admin / admin123
Env vars: PORT, ADMIN_USER, ADMIN_PASS. Data is saved in data.json (auto-created).
