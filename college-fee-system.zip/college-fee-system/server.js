// College Fee System - pure Node.js (no external dependencies)
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin123';
const DATA_FILE = path.join(__dirname, 'data.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_MS = 8 * 60 * 60 * 1000;

/* ---------- storage ---------- */
let db = { students: [], payments: [], counters: { student: 0, receipt: 0 } };
if (fs.existsSync(DATA_FILE)) {
  try { db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { console.error('Could not read data.json, starting fresh'); }
}
function save() {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

/* ---------- helpers ---------- */
const sessions = new Map();
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'Content-Type': type });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 1e6) { reject(new Error('Body too large')); req.destroy(); } });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('Invalid JSON')); } });
  });
}
function authed(req, url) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : url.searchParams.get('token');
  const exp = token && sessions.get(token);
  if (!exp || exp < Date.now()) { sessions.delete(token); return false; }
  return true;
}
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => Number(v);
const money = n => '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function paidBy(studentId) {
  return db.payments.filter(p => p.studentId === studentId).reduce((s, p) => s + p.amount, 0);
}
function withFees(s) {
  const net = s.totalFee - (s.discount || 0);
  const paid = paidBy(s.id);
  const due = Math.max(net - paid, 0);
  return { ...s, netFee: net, paid, due, status: due === 0 ? 'Paid' : paid > 0 ? 'Partial' : 'Unpaid' };
}
function validateStudent(b, existingId) {
  const errs = [];
  const name = String(b.name || '').trim();
  const course = String(b.course || '').trim();
  const totalFee = num(b.totalFee);
  const discount = num(b.discount || 0);
  if (!name) errs.push('Name is required');
  if (!course) errs.push('Course is required');
  if (!Number.isFinite(totalFee) || totalFee <= 0) errs.push('Total fee must be greater than 0');
  if (!Number.isFinite(discount) || discount < 0 || discount > totalFee) errs.push('Discount must be between 0 and total fee');
  let rollNo = String(b.rollNo || '').trim();
  if (rollNo && db.students.some(s => s.rollNo.toLowerCase() === rollNo.toLowerCase() && s.id !== existingId)) errs.push('Roll number already exists');
  return {
    errs,
    value: { name, course, rollNo, year: String(b.year || '').trim(), phone: String(b.phone || '').trim(), email: String(b.email || '').trim(), totalFee, discount }
  };
}

/* ---------- API ---------- */
async function api(req, res, url) {
  const { pathname } = url;
  const method = req.method;

  if (pathname === '/api/login' && method === 'POST') {
    const b = await readBody(req);
    if (b.username === ADMIN_USER && b.password === ADMIN_PASS) {
      const token = crypto.randomBytes(24).toString('hex');
      sessions.set(token, Date.now() + SESSION_MS);
      return send(res, 200, { token });
    }
    return send(res, 401, { error: 'Invalid username or password' });
  }

  if (!authed(req, url)) return send(res, 401, { error: 'Not logged in' });

  if (pathname === '/api/logout' && method === 'POST') {
    const h = req.headers.authorization || '';
    sessions.delete(h.slice(7));
    return send(res, 200, { ok: true });
  }

  if (pathname === '/api/dashboard' && method === 'GET') {
    const list = db.students.map(withFees);
    const today = new Date().toISOString().slice(0, 10);
    return send(res, 200, {
      students: list.length,
      totalBilled: list.reduce((s, x) => s + x.netFee, 0),
      totalCollected: list.reduce((s, x) => s + x.paid, 0),
      totalDue: list.reduce((s, x) => s + x.due, 0),
      collectedToday: db.payments.filter(p => p.date.slice(0, 10) === today).reduce((s, p) => s + p.amount, 0),
      fullyPaid: list.filter(x => x.status === 'Paid').length,
      defaulters: list.filter(x => x.due > 0).sort((a, b) => b.due - a.due).slice(0, 5),
      recent: db.payments.slice(-5).reverse()
    });
  }

  if (pathname === '/api/students' && method === 'GET') {
    const q = (url.searchParams.get('q') || '').toLowerCase();
    let list = db.students.map(withFees);
    if (q) list = list.filter(s => [s.name, s.rollNo, s.course].some(v => String(v).toLowerCase().includes(q)));
    return send(res, 200, list);
  }

  if (pathname === '/api/students' && method === 'POST') {
    const b = await readBody(req);
    const { errs, value } = validateStudent(b);
    if (errs.length) return send(res, 400, { error: errs.join('. ') });
    db.counters.student += 1;
    const id = db.counters.student;
    if (!value.rollNo) value.rollNo = 'STU' + String(id).padStart(4, '0');
    const student = { id, ...value, createdAt: new Date().toISOString() };
    db.students.push(student);
    save();
    return send(res, 201, withFees(student));
  }

  let m = pathname.match(/^\/api\/students\/(\d+)$/);
  if (m) {
    const id = Number(m[1]);
    const idx = db.students.findIndex(s => s.id === id);
    if (idx === -1) return send(res, 404, { error: 'Student not found' });
    if (method === 'GET') {
      return send(res, 200, { ...withFees(db.students[idx]), payments: db.payments.filter(p => p.studentId === id) });
    }
    if (method === 'PUT') {
      const b = await readBody(req);
      const { errs, value } = validateStudent(b, id);
      if (errs.length) return send(res, 400, { error: errs.join('. ') });
      if (!value.rollNo) value.rollNo = db.students[idx].rollNo;
      if (value.totalFee - value.discount < paidBy(id)) return send(res, 400, { error: 'Net fee cannot be less than the amount already paid' });
      db.students[idx] = { ...db.students[idx], ...value };
      save();
      return send(res, 200, withFees(db.students[idx]));
    }
    if (method === 'DELETE') {
      if (db.payments.some(p => p.studentId === id)) return send(res, 409, { error: 'Cannot delete a student who has payments recorded' });
      db.students.splice(idx, 1);
      save();
      return send(res, 200, { ok: true });
    }
  }

  if (pathname === '/api/payments' && method === 'GET') {
    const sid = url.searchParams.get('studentId');
    let list = db.payments;
    if (sid) list = list.filter(p => p.studentId === Number(sid));
    return send(res, 200, list.slice().reverse());
  }

  if (pathname === '/api/payments' && method === 'POST') {
    const b = await readBody(req);
    const student = db.students.find(s => s.id === Number(b.studentId));
    if (!student) return send(res, 404, { error: 'Student not found' });
    const amount = num(b.amount);
    const mode = ['Cash', 'UPI', 'Card', 'Cheque', 'Bank Transfer'].includes(b.mode) ? b.mode : null;
    const f = withFees(student);
    if (!Number.isFinite(amount) || amount <= 0) return send(res, 400, { error: 'Enter a valid amount' });
    if (!mode) return send(res, 400, { error: 'Choose a payment mode' });
    if (amount > f.due + 0.001) return send(res, 400, { error: `Amount exceeds the due balance of ${money(f.due)}` });
    db.counters.receipt += 1;
    const payment = {
      id: db.counters.receipt,
      receiptNo: 'RCP-' + new Date().getFullYear() + '-' + String(db.counters.receipt).padStart(5, '0'),
      studentId: student.id, studentName: student.name, rollNo: student.rollNo, course: student.course,
      amount, mode, note: String(b.note || '').trim(), date: new Date().toISOString()
    };
    db.payments.push(payment);
    save();
    return send(res, 201, { payment, student: withFees(student) });
  }

  return send(res, 404, { error: 'Not found' });
}

/* ---------- printable receipt ---------- */
function receiptPage(res, id) {
  const p = db.payments.find(x => x.id === id);
  if (!p) return send(res, 404, '<h1>Receipt not found</h1>', 'text/html; charset=utf-8');
  const s = db.students.find(x => x.id === p.studentId);
  const f = s ? withFees(s) : null;
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(p.receiptNo)}</title>
<style>body{font-family:Arial,sans-serif;max-width:640px;margin:30px auto;padding:24px;border:2px solid #222}
h1{text-align:center;margin:0}h2{text-align:center;margin:4px 0 20px;font-weight:normal;color:#555}
table{width:100%;border-collapse:collapse}td{padding:8px;border-bottom:1px solid #ddd}td:first-child{color:#555;width:40%}
.amt{font-size:22px;font-weight:bold}.foot{margin-top:40px;display:flex;justify-content:space-between}
button{margin-top:20px;padding:8px 16px}@media print{button{display:none}}</style></head><body>
<h1>College Fee Receipt</h1><h2>${esc(p.receiptNo)}</h2>
<table>
<tr><td>Date</td><td>${esc(new Date(p.date).toLocaleString('en-IN'))}</td></tr>
<tr><td>Student</td><td>${esc(p.studentName)}</td></tr>
<tr><td>Roll No</td><td>${esc(p.rollNo)}</td></tr>
<tr><td>Course</td><td>${esc(p.course)}</td></tr>
<tr><td>Payment mode</td><td>${esc(p.mode)}</td></tr>
${p.note ? `<tr><td>Note</td><td>${esc(p.note)}</td></tr>` : ''}
<tr><td>Amount paid</td><td class="amt">${money(p.amount)}</td></tr>
${f ? `<tr><td>Total paid so far</td><td>${money(f.paid)}</td></tr><tr><td>Balance due</td><td>${money(f.due)}</td></tr>` : ''}
</table>
<div class="foot"><span>Student signature</span><span>Accounts office</span></div>
<button onclick="window.print()">Print</button></body></html>`;
  send(res, 200, html, 'text/html; charset=utf-8');
}

/* ---------- static files ---------- */
function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR)) return send(res, 403, 'Forbidden', 'text/plain');
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Not found', 'text/plain');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
}

/* ---------- server ---------- */
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    const rm = url.pathname.match(/^\/receipt\/(\d+)$/);
    if (rm) {
      if (!authed(req, url)) return send(res, 401, '<h1>Please log in first</h1>', 'text/html; charset=utf-8');
      return receiptPage(res, Number(rm[1]));
    }
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    serveStatic(req, res, url);
  } catch (e) {
    send(res, 400, { error: e.message || 'Bad request' });
  }
});

server.listen(PORT, () => {
  console.log(`College Fee System running at http://localhost:${PORT}`);
  console.log(`Login: ${ADMIN_USER} / ${ADMIN_PASS}`);
});
